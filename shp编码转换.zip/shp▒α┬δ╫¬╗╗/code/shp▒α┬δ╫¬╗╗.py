#! /usr/bin/env python
# -*- coding: utf-8 -*-
# __author__ = "Uncle Xiang"
# Email: tuxgis@126.com
# Time: 2020/4/28 20:47
# version: python 27

import struct
import arcpy
import sys
reload(sys)
sys.setdefaultencoding('utf8')
def get_LDID(dbf):
    dat = open(dbf, 'rb').read(30)[29:]
    id = struct.unpack('B', dat)[0]
    return id

def set_LDID(dbf, code):
    with open(dbf,'r+b') as f:
        print(f)
        f.seek(29,0)
        f.write(struct.pack('B', code))

def main(dbf,code):
    id = get_LDID(dbf)
    if id == 0:
        arcpy.AddMessage('source shapefile encoding: utf8')
    elif id == 77:
        arcpy.AddMessage('source shapefile encoding: gbk')
    elif id == 87:
        arcpy.AddMessage('source shapefile encoding: ANSI')
    else:
        arcpy.AddMessage('source shapefile encoding: '+id+',please click: http://shapelib.maptools.org/codepage.html')

    set_LDID(dbf,code)

inshp = arcpy.GetParameterAsText(0)
arcpy.AddMessage(inshp)
arcpy.AddMessage('Startting...')
code = str(arcpy.GetParameterAsText(1))
if code == "utf-8":
    main(inshp, 0)
elif code == "gbk":
    main(inshp,77)
else:
    arcpy.AddMessage('please select right encoding!')
arcpy.AddMessage('end!!!')